# KaZeTab v2 Product Strategy

## Positioning
KaZeTab should stop competing as "just another wallpaper new tab" and instead win as a calm, fast, mood-aware launchpad.

Product promise:
"Open a new tab, feel calmer, and get back to what matters in seconds."

## The User Problem
People open new tabs many times a day and get one of three frustrating experiences:
- visual clutter
- wasted time getting back to their flow
- no sense of calm or personalization

KaZeTab should solve all three with a page that feels useful immediately, not just pretty.

## Core Jobs To Be Done
1. Calm me down.
2. Help me restart fast.
3. Match my mood and time of day.

## Product Pillars
- Speed: the page should feel instant, even if the network is slow.
- Trust: minimal permissions, predictable behavior, no hijack feeling.
- Focus: only show things that help people continue what they were about to do.
- Personality: bold visuals, strong themes, a clear sense of mood.

## Target Users
- Students who want a study or chill tab experience.
- Developers who open many tabs and want a cleaner launchpad.
- General users who like wallpaper personalization but still need utility.

## v2 Feature Scope
Must-have:
- Reliable wallpaper rotation
- Mood and time-of-day themes
- Search that respects the browser experience
- Quick access bookmarks
- Clean settings flow
- Graceful fallback behavior when wallpaper fetches fail

Next:
- Favorites collection
- Focus note / one-line daily intention
- Clock and date
- Theme packs
- Better onboarding

Avoid for now:
- Heavy widget dashboards
- News feeds
- AI features without a clear use case
- More permissions than necessary

## Success Metrics
- Install to day-7 retention
- Frequency of manual wallpaper refresh
- Percentage of users who complete setup
- Disable and uninstall feedback themes
- Review sentiment around speed, beauty, and usefulness

## Build Order
1. Fix reliability and settings consistency.
2. Improve first-run and daily-use experience.
3. Polish visuals and responsiveness.
4. Tighten store listing, screenshots, and release quality.
